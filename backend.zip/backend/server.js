require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const contactRoutes = require("./routes/contact.routes");

const app = express();
const PORT = process.env.PORT || 3001;

/* Sécurité de base */
app.use(helmet());

/* CORS */
app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "http://localhost:3000",
      "https://fiduciaireduhetre.ch",
      "https://www.fiduciaireduhetre.ch",
    ],
    methods: ["GET", "POST"],
    allowedHeaders: ["Content-Type"],
  })
);

/* Body parser */
app.use(express.json());

/* Route test */
app.get("/api/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    message: "API Fiduciaire du Hêtre opérationnelle",
  });
});
app.use("/api/contact", contactRoutes);

/* Lancement serveur */
app.listen(PORT, () => {
  console.log(`✅ Backend démarré sur le port ${PORT}`);
});
