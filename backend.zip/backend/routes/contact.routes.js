const express = require("express");
const rateLimit = require("express-rate-limit");
const validator = require("validator");
const { sendMail } = require("../services/mailer");

const router = express.Router();

/* Anti-spam : max 5 requêtes / 15 min / IP */
const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  message: {
    error: "Trop de requêtes. Veuillez réessayer plus tard.",
  },
});

/* POST /api/contact/send */
router.post("/send", contactLimiter, async (req, res) => {
  const { fname, lname, email, subject, message, honeypot } = req.body;

  // Honeypot anti-bot
  if (honeypot) {
    return res.status(200).json({ message: "OK" });
  }

  // Validation des champs
  if (!fname || !lname || !email || !subject || !message) {
    return res
      .status(400)
      .json({ error: "Tous les champs sont obligatoires." });
  }

  if (!validator.isEmail(email)) {
    return res.status(400).json({ error: "Adresse email invalide." });
  }

  if (message.length < 10) {
    return res.status(400).json({ error: "Le message est trop court." });
  }

  try {
    // --- Email à la fiduciaire ---
    await sendMail({
      from: process.env.MAIL_FROM,
      to: process.env.MAIL_TO,
      replyTo: email,
      subject: `📩 Nouveau contact – ${fname} ${lname}`,
      html: `
        <h2>Nouveau message depuis le site</h2>
        <p><strong>Nom :</strong> ${fname} ${lname}</p>
        <p><strong>Email :</strong> ${email}</p>
        <p><strong>Sujet :</strong> ${subject}</p>
        <p><strong>Message :</strong><br/>${message}</p>
      `,
    });

    // --- Email de confirmation client ---
    await sendMail({
      from: process.env.MAIL_FROM,
      to: email,
      subject: "Confirmation de votre message – Fiduciaire du Hêtre",
      html: `
        <p>Bonjour ${fname},</p>
        <p>Nous avons bien reçu votre message concernant <strong>${subject}</strong>.</p>
        <p>Nous vous répondrons dans les plus brefs délais.</p>
        <p>Cordialement,<br/>Fiduciaire du Hêtre</p>
      `,
    });

    // Réponse API
    return res.status(200).json({
      message: "✅ Votre message a été envoyé avec succès.",
    });
  } catch (err) {
    console.error("❌ Erreur envoi email :", err);

    return res.status(500).json({
      error: "Erreur lors de l’envoi du message. Veuillez réessayer plus tard.",
    });
  }
});

module.exports = router;
