const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false, // STARTTLS
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

transporter.verify((error) => {
  if (error) {
    console.error("❌ SMTP erreur :", error);
  } else {
    console.log("✅ SMTP prêt à envoyer des emails");
  }
});

async function sendMail(options) {
  return transporter.sendMail(options);
}

module.exports = { sendMail };
